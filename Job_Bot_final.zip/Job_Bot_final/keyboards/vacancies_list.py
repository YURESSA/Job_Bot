from aiogram import types
from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder

from database.get_vacancy_info import get_vacancy_name


def get_vacancies_list_kb(vacancies: list) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for vac in vacancies:
        builder.add(types.InlineKeyboardButton(
            text=get_vacancy_name(vac[0]),
            callback_data=["delete_vacancy", vac[0]])
        )
    builder.adjust(1)
    return builder.as_markup()
