from aiogram import types
from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder, ReplyKeyboardBuilder, ReplyKeyboardMarkup


def like_dislike_inline() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.add(types.InlineKeyboardButton(
        text="👍",
        callback_data="like_vacancy")
    )
    builder.add(types.InlineKeyboardButton(
        text="👎",
        callback_data="dis_vacancy")
    )
    return builder.as_markup()


def like_dislike() -> ReplyKeyboardMarkup:
    kb = [
        [
            types.KeyboardButton(text="👍"),
            types.KeyboardButton(text="👎"),
            types.KeyboardButton(text="⚙")
        ],
    ]
    keyboard = types.ReplyKeyboardMarkup(
        keyboard=kb,
        resize_keyboard=True,
        input_field_placeholder="Как вам вакансия?"
    )
    return keyboard
