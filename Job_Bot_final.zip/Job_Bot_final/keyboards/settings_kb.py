from aiogram import types
from aiogram.types import InlineKeyboardMarkup
from aiogram.utils.keyboard import InlineKeyboardBuilder
from database.get_user_info import get_city, get_min_salary,  is_turbo_mode


def get_settings_kb(user_id: int) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.add(types.InlineKeyboardButton(
        text="Пересоздать анкету🔁",
        callback_data="create_form_worker")
    )
    builder.add(types.InlineKeyboardButton(
        text="Город: " + get_city(user_id) + '🏢',
        callback_data="update_user_city")
    )
    builder.add(types.InlineKeyboardButton(
        text="Минимальная зарплата: " + str(get_min_salary(user_id)) + '₽',
        callback_data="update_user_min_salary")
    )
    turbo = is_turbo_mode(user_id)
    if turbo == 1:
        turbo = 'Включен✅'
    else:
        turbo = "Выключен❌"
    builder.add(types.InlineKeyboardButton(
        text="Турбо режим: " + turbo,
        callback_data="update_turbo_mode")
    )
    builder.add(types.InlineKeyboardButton(
        text="Создать вакансию⌨",
        callback_data="create_vacancy"
    ))
    builder.add(types.InlineKeyboardButton(
        text="Список ваших вакансий📃",
        callback_data="get_user_vacancies"
    ))
    builder.add(types.InlineKeyboardButton(
        text="Продолжить🚀",
        callback_data="continue")
    )
    builder.adjust(1)
    return builder.as_markup()