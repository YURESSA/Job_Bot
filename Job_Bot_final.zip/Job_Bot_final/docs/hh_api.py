import json
import requests
from database.add_vacancy import add_vacancy_info
import logging
import re
import pandas as pd

def getPage(city, obl, page=0):
    req = requests.get('https://api.hh.ru/areas')  # Посылаем запрос к API
    data = req.content.decode()
    jsObj = json.loads(data)
    f = 1
    id = 1
    for el in jsObj[0]['areas']:
        if el['name'] == obl:
            for el1 in el['areas']:
                if re.search(r'\b'+city.capitalize()+'\W', el1['name']):
                    id = (el1['id'])
                    f = 0
                    break
            if f == 0:
                break
        if f == 0:
            break
    params = {
        'area': id,  # Поиск ощуществляется по вакансиям города Москва
        'page': page,  # Индекс страницы поиска на HH
        'per_page': 100  # Кол-во вакансий на 1 странице
    }
    req = requests.get('https://api.hh.ru/vacancies', params)  # Посылаем запрос к API
    data = req.content.decode()  # Декодируем его ответ, чтобы Кириллица отображалась корректно
    req.close()
    return data


def get_and_check(find_city, mp=4):
    city = [find_city]
    url = 'https://ru.wikipedia.org/wiki/%D0%A1%D0%BF%D0%B8%D1%81%D0%BE%D0%BA_%D0%B3%D0%BE%D1%80%D0%BE%D0%B4%D0%BE%D0%B2_%D0%A0%D0%BE%D1%81%D1%81%D0%B8%D0%B8'
    df = pd.read_html(url)[0]
    sp = [i for i in dict(df['Город']).values()]
    if city[0] in sp:
        for cit in city:
            geocoder_request = f"http://geocode-maps.yandex.ru/1.x/?apikey=40d1649f-0493-4b70-98ba-98533de7710b&geocode={cit}&format=json"
            response = requests.get(geocoder_request)
            if response:
                json_response = response.json()
                toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]
                toponym_address = toponym["metaDataProperty"]['GeocoderMetaData']['Address']['Components'][2]['name']
                print(f'{cit}: {toponym_address}')
            else:
                print("Ошибка выполнения запроса:")
                print(geocoder_request)
                print("Http статус:", response.status_code, "(", response.reason, ")")



        for page in range(0, mp + 1):
            # Преобразуем текст ответа запроса в справочник Python
            jsObj = json.loads(getPage(find_city, toponym_address, page=page))
            salary = 0
            employer = "Не указано"
            requirement = "Не указано"
            responsibility = "Не указано"
            vak_url = "Не указано"
            if 'items' in jsObj:
                for to_db in jsObj['items']:
                    try:
                        vaсancy = to_db['name']
                        city_name = find_city
                        salary = to_db['salary']['from']
                        employer = to_db['employer']['name']
                        requirement = to_db['snippet']['requirement']
                        responsibility = to_db['snippet']['responsibility']
                        vak_url = to_db['apply_alternate_url']
                    except AttributeError:
                        pass
                    except TypeError:
                        pass
                    if vaсancy and city_name and salary and employer and requirement and responsibility and vak_url:
                        data = {'vacancy_name' : vaсancy,
                            'requirement' : requirement,
                            'responsibility' : responsibility,
                            'salary' : salary,
                            'employer' : employer,
                            'city_name' : city_name,
                            'url' : vak_url}
                        add_vacancy_info(data)
                        logging.info("Добавляю в БД")

