import os, requests
from bing_image_urls import bing_image_urls


def check_valid(urls):
    for url in urls:
        try:
            check = requests.head(url, timeout=4)
            if check.status_code == 200 and 'hh.ru' not in url:
                return [url]
        except:
            pass


def get_all_images(query, city):
    #query = query + ' ' + city
    urls = bing_image_urls(query, limit=100)
    return check_valid(urls)


