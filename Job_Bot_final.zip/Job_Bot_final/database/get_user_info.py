import sqlite3

DB_URL = "database/YandexBot.sqlite3"


def is_turbo_mode(user_id):
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()
    status = cur.execute("SELECT turbo_mode FROM workers WHERE user_id = (?)", (user_id,)).fetchone()[0]
    return status


def get_last_vacancy(user_id: int):
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()
    id_ = cur.execute("SELECT last_vacancy_id FROM workers WHERE user_id = (?)", (user_id,)).fetchone()[0]
    return id_


def get_user_name(user_id: int):
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()
    name = cur.execute("SELECT user_full_name FROM workers WHERE user_id = (?)", (user_id,)).fetchone()[0]
    return name


def get_city(user_id: int):
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()
    city = cur.execute("SELECT user_city FROM workers WHERE user_id = (?)", (user_id,)).fetchone()[0]
    return city


def get_min_salary(user_id: int):
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()
    salary = cur.execute("SELECT min_salary FROM workers WHERE user_id = (?)", (user_id,)).fetchone()[0]
    return salary


def get_user_about(user_id: int):
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()
    about = cur.execute("SELECT user_about FROM workers WHERE user_id = (?)", (user_id,)).fetchone()[0]
    return about


def get_worker_city(user_id: int):
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()

    if is_worker_in_db:
        city_name = cur.execute("""SELECT user_city FROM workers WHERE user_id = ?""", (user_id,)).fetchone()[0]
        return city_name
    return "Москва"


def is_worker_in_db(user_id: int):
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()

    status = cur.execute("""SELECT id FROM workers WHERE user_id = ?""", (user_id,)).fetchone()[0]
    if status is None:
        return False
    return True


def get_user_vacancies(user_id: int) -> list:
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()

    name = get_user_name(user_id)

    vac = cur.execute("""SELECT id FROM vacancies WHERE employer = ?""", (name,)).fetchall()
    cur.close()
    return vac


def is_user_name_valid(user_name: str):
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()

    name = cur.execute("""SELECT id FROM workers WHERE user_full_name = ?""", (user_name,)).fetchone()[0]
    if name is None:
        return True
    return False
