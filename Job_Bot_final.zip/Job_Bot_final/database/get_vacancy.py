import sqlite3
from docs.hh_api import get_and_check
from database.get_user_info import get_min_salary, get_worker_city

DB_URL = "database/YandexBot.sqlite3"


def get_rnd_vacancy(user_id: int) -> dict:
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()
    city = get_worker_city(user_id)
    min_salary = get_min_salary(user_id)
    data = cur.execute(
        """SELECT id, vacancy_name, requirement, responsibility, salary, employer, url FROM vacancies WHERE city_name = (?) AND salary >= (?) order by RANDOM() LIMIT 1""",
        (city, min_salary)).fetchall()
    cur.close()
    cur = conn.cursor()

    data1 = cur.execute(
        "SELECT * FROM vacancies WHERE city_name = (?)",
        (city,)).fetchall()
    cur.close()
    if len(data1) > 50:
        data_dict = {
            "id": data[0][0],
            "vacancy_name":  data[0][1],
            "requirement":  data[0][2],
            "responsibility":  data[0][3],
            "salary":  data[0][4],
            "employer":  data[0][5],
            "url":  data[0][6]
        }
        # return list(data[0])
        return data_dict
    else:
        get_and_check(city)
        conn = sqlite3.connect(DB_URL)
        cur = conn.cursor()

        data = cur.execute(
            "SELECT id, vacancy_name, requirement, responsibility, salary, employer, url FROM vacancies WHERE city_name = (?) AND salary >= (?) order by RANDOM() LIMIT 1",
            (city, min_salary)).fetchall()
        cur.close()
        if len(data) != 0:
            data_dict = {
                "id": data[0][0],
                "vacancy_name": data[0][1],
                "requirement": data[0][2],
                "responsibility": data[0][3],
                "salary": data[0][4],
                "employer": data[0][5],
                "url": data[0][6]
            }
            # return list(data[0])
            return data_dict
        else:
            return ['Мы не нашли информацию в данном городе :(']
