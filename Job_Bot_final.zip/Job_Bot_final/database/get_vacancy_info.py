import sqlite3


def get_vacancy_contact(vacancy_id):
    conn = sqlite3.connect("database/YandexBot.sqlite3")
    cur = conn.cursor()

    data = cur.execute(
        "SELECT url FROM vacancies WHERE id = ?",
        (vacancy_id,)).fetchone()[0]
    cur.close()
    return data


def get_vacancy_name(vacancy_id):
    conn = sqlite3.connect("database/YandexBot.sqlite3")
    cur = conn.cursor()

    name = cur.execute(
        "SELECT vacancy_name FROM vacancies WHERE id = ?",
        (vacancy_id,)).fetchone()[0]
    cur.close()
    return name


def delete_vacancy(vacancy_id):
    conn = sqlite3.connect("database/YandexBot.sqlite3")
    cur = conn.cursor()
    cur.execute("DELETE FROM vacancies WHERE id = (?)", (vacancy_id,))
    conn.commit()
    cur.close()


def get_vacancy_owner_id(vacancy_id):
    conn = sqlite3.connect("database/YandexBot.sqlite3")
    cur = conn.cursor()

    owner = cur.execute(
        "SELECT owner_telegram_id FROM vacancies WHERE id = ?",
        (vacancy_id,)).fetchone()[0]
    cur.close()
    return owner
