import sqlite3
from database.get_user_info import is_worker_in_db

DB_URL = "database/YandexBot.sqlite3"


class AddWorkerError(Exception):
    pass


def add_worker_info(data: dict):
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()

    if is_worker_in_db(data["user_id"]):
        delete_worker_from_db(data["user_id"])
    cur.execute(
        """INSERT INTO workers (user_id, user_full_name, user_about, user_city, user_image_id, turbo_mode, min_salary) VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (data["user_id"], data["user_full_name"], data["user_about"], data["user_city"], data["user_image_id"], 0, 0))
    conn.commit()
    cur.close()


def delete_worker_from_db(user_id: str):
    conn = sqlite3.connect(DB_URL)
    cur = conn.cursor()

    cur.execute("""DELETE FROM workers WHERE user_id = ?""", (user_id,))
    conn.commit()
    cur.close()
