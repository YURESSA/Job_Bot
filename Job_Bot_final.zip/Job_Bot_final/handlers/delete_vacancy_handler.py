import queue

from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.filters.text import Text
from aiogram.types import Message, ReplyKeyboardRemove
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from keyboards.for_new_form_kb import get_new_form_kb
from aiogram.utils.text_decorations import MarkdownDecoration
import re
from aiogram.filters import CommandObject

from database.get_vacancy_info import get_vacancy_owner_id, delete_vacancy
from database.get_user_info import get_user_name

router = Router()


@router.message(Command("del_id"))
async def cmd_name(message: types.Message, command: CommandObject):
    if command.args:
        if message.from_user.id == get_vacancy_owner_id(command.args):
            delete_vacancy(command.args)
            await message.answer("Вакансия удалена 🗑️")
        else:
            print(message.from_user.id)
            print(get_vacancy_owner_id(command.args))
            await message.answer("Ошибка❌ Вы не являетесь владельцем этой вакансии")
    else:
        await message.answer("Пожалуйста, укажите ID вакансии после команды /del_id!")
