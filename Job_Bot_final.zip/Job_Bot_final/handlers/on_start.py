from aiogram import Router, types, F
from aiogram.filters import Command
from aiogram.filters.text import Text
from aiogram.types import Message, ReplyKeyboardRemove
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from keyboards.for_new_form_kb import get_new_form_kb
from main import bot
from database.add_worker import add_worker_info
from database.add_vacancy import add_vacancy_info
from database.get_user_info import get_user_name, is_user_name_valid
from handlers.get_rnd_vacancy_cmd import cmd_get_random
from database.get_user_info import is_worker_in_db

router = Router()  # [1]


# Хэндлер на команду /start
@router.message(Command("start"))
async def cmd_start(message: Message):
    await message.answer(f"Привет! Давай заполним твою анкету, без неё продолжать будет нельзя",
                         reply_markup=get_new_form_kb())


class CreateWorkerForm(StatesGroup):
    inputName = State()
    inputAbout = State()
    inputCity = State()
    inputImage = State()


# Блок собработкой анкеты для worker'a
# Обработчик inline клавиатуры
@router.callback_query(Text("create_form_worker"))
async def get_worker_form(callback: types.CallbackQuery, state: FSMContext):
    await callback.message.answer("Введи ваше полное имя")
    await callback.answer()
    # Перевод в редим ожидания
    await state.set_state(CreateWorkerForm.inputName)


# Ловит имя
@router.message(CreateWorkerForm.inputName, F.text)
async def get_name(message: Message, state: FSMContext):
    # if not is_user_name_valid(message.text):
    #     await message.answer("Это имя уже занято")
    #     return
    await state.update_data(user_full_name=message.text)
    await message.answer("Напишите о себе")
    await state.set_state(CreateWorkerForm.inputAbout)


# Ловит доп. инф.
@router.message(CreateWorkerForm.inputAbout, F.text)
async def get_about(message: Message, state: FSMContext):
    await state.update_data(user_about=message.text)
    # Далее надо сделать кнопку "Работать из дома" или "Все города"
    # Можно выдавать вакансии, в зависимости от этого
    await message.answer("Спасибо. Теперь напишите, в каком городе ты ищешь работу?(Можно будет изменить в фильтрах)")
    await state.set_state(CreateWorkerForm.inputCity)


# Ловит город, где ищет работу
@router.message(CreateWorkerForm.inputCity, F.text)
async def get_about(message: Message, state: FSMContext):
    await state.update_data(user_city=message.text.capitalize())
    await message.answer("Теперь отправьте мне своё фото")
    await state.set_state(CreateWorkerForm.inputImage)


# Ловит фото
# Отправялет полученные данные - тест
# Долеенеобходимо сохнанять всё в БД
@router.message(CreateWorkerForm.inputImage, F.photo)
async def get_image(message: Message, state: FSMContext):
    await state.update_data(user_image_id=message.photo[-1].file_id)
    user_data = await state.get_data()
    user_data["user_id"] = message.from_user.id
    add_worker_info(user_data)
    await message.answer("Отлично, все хорошо")
    await cmd_get_random(message)
    # await bot.send_photo(message.chat.id, photo=user_data["image_id"],
    #                      caption=f"""{user_data["name"]}\n{user_data["about"]}""")
    await state.clear()


class CreateVacancyForm(StatesGroup):
    inputName = State()
    inputRequirement = State()
    inputResponsibility = State()
    inputCity = State()
    inputSalary = State()
    inputContacts = State()
    # Пользователю предлагают установить ввиде фото фотографию здания. Необходимо использовать изученное API
    # inputImage = State()


# Блок с обработкой анкеты для вакансий
# Обработчик inline клавиатуры
@router.callback_query(Text("create_vacancy"))
async def get_vacancy(callback: types.CallbackQuery, state: FSMContext):
    if not is_worker_in_db(callback.from_user.id):
        await callback.message.answer("Ошибка! С начала создайте свою анкету")
        return
    await callback.message.answer("Введите название должности")
    await callback.answer()
    # Перевод в редим ожидания
    await state.set_state(CreateVacancyForm.inputName)


# Ловит имя
@router.message(CreateVacancyForm.inputName, F.text)
async def get_vacancy_name(message: Message, state: FSMContext):
    await state.update_data(vacancy_name=message.text)
    await message.answer("Введите требования к работнику")
    await state.set_state(CreateVacancyForm.inputRequirement)


# Ловит доп инф
@router.message(CreateVacancyForm.inputRequirement, F.text)
async def get_vacancy_requirement(message: Message, state: FSMContext):
    await state.update_data(requirement=message.text)
    await message.answer("Введите обязанности работника")
    await state.set_state(CreateVacancyForm.inputResponsibility)


# Ловит адрес
@router.message(CreateVacancyForm.inputResponsibility, F.text)
async def get_vacancy_responsibility(message: Message, state: FSMContext):
    await state.update_data(responsibility=message.text)
    await message.answer("Введите город работы")
    await state.set_state(CreateVacancyForm.inputCity)


# Ловит адрес
@router.message(CreateVacancyForm.inputCity, F.text)
async def get_vacancy_city(message: Message, state: FSMContext):
    await state.update_data(city_name=message.text)
    await message.answer("Введите зарплату")
    await state.set_state(CreateVacancyForm.inputSalary)


@router.message(CreateVacancyForm.inputSalary, F.text)
async def get_vacancy_salary(message: Message, state: FSMContext):
    await state.update_data(salary=message.text)
    await message.answer("Введите контакты для связи с вами")
    await state.set_state(CreateVacancyForm.inputContacts)


@router.message(CreateVacancyForm.inputContacts, F.text)
async def get_vacancy_contacts(message: Message, state: FSMContext):
    await state.update_data(url=message.text)
    data = await state.get_data()
    data["employer"] = get_user_name(message.from_user.id)
    add_vacancy_info(data, message.from_user.id)
    await message.answer("Вакансия сохранена")
    await state.clear()
# Ловит фото
# Отправялет полученные данные - тест
# Долеенеобходимо сохнанять всё в БД
# @router.message(CreateVacancyForm.inputImage, F.photo)
# async def get_image_employer(message: Message, state: FSMContext):
#     await state.update_data(image=message.photo[-1].file_id)
#     employer_data = await state.get_data()
#     await bot.send_photo(message.chat.id, employer_data["image"],
#                          caption=f"""{employer_data["name"]}\n{employer_data["about"]}\n{employer_data["address"]}""")
#     await state.clear()
